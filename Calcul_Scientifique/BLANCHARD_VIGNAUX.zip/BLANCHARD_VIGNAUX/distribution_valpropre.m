clear all;
close all;

n= 100;

[A,val_propre, info] = matgen_csad();